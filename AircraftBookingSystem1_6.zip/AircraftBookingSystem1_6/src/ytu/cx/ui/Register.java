/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ytu.cx.ui;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import ytu.cx.util.MD5password;
import ytu.cx.util.Tool;
import static ytu.cx.util.Tool.checkID;
/**
 *
 * @author changxuan
 */
public class Register extends JFrame{
    private String username=null;
    private String userName=null;
    private String password=null;
    private String fileNames=null;
    private MyPanel panel;
    private JLabel lan_Name = new JLabel("����:"),fuHao = new JLabel();
    private JTextField jtn_Name = new JTextField();
    private JLabel lab_zhanghao = new JLabel("����֤��:");
    private JTextField jta_text = new JTextField();
    Font lab = new Font("����",1,20);
    private JLabel lat_password = new JLabel("��¼����:");
    Font lat  = new Font("����",1,20);
    private JPasswordField jtb_text = new JPasswordField();
    private JButton btn_register = new JButton("ע��");
    private JButton btn_land = new JButton("����");
    private JButton btn_back = new JButton("�ر�");
    Font btn = new Font("����",2,30);
    public static  int pd = 0;
    public static String adName,ak1, ak2;
    private Container contentPane = this.getContentPane();
    public String getUserName(){
    	return userName;
    }
    public Register () {
        this.setSize(400,238);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setIconImage(new ImageIcon("Plane.png").getImage());
        this.setTitle("ע���˺�");
        this.setUndecorated(true);
        this.setResizable(false);
        /**
         * ע�ᰴť
         */
        btn_register.addActionListener(new ActionListener() {
            @SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
                pd = 1;
                adName=jtn_Name.getText();
                ak1 = jta_text .getText();
                ak2 = jtb_text .getText();
                
                //���ж�����֤���Ƿ����
                
                     	File fileNames=new File("./user/users.dat");
                        if(Tool.judeFileExists(fileNames))
                	try{
                	FileReader inOne=new FileReader(fileNames);
                	BufferedReader inTwo=new BufferedReader(inOne);
                	String s=null;
                	int judge=1;
                	while((s=inTwo.readLine())!=null)
                	{
                            String[] strsss=new String[3];
                            strsss=s.split("&&");
                	      System.out.println(strsss[0]+strsss[1]+strsss[2]);
                              //�������֤���Ѵ��� ��judge=0 
                            if(jta_text.getText().equals(strsss[1])) {
                                judge=0;
                                break;
                            }
                	}  
                	inTwo.close();
                        inOne.close();
                        if(judge==0){
                             JOptionPane.showMessageDialog(null,"����֤���Ѵ��ڣ�\n����ϵϵͳ����Ա",null,JOptionPane.ERROR_MESSAGE);
                             return;
                        }
                        }
                        catch(IOException event){
                		JOptionPane.showMessageDialog(null,"ϵͳ����"+event,null,JOptionPane.ERROR_MESSAGE, null);
                	}
                //checkID() ����  ʹ���������ʽ���ж�����֤���Ƿ���ȷ
                if((checkID(ak1)||adName.equals("admin"))&&!ak1.equals("")&&!ak2.equals("")){
                String fileName = "./user/users.dat";
                try {
                    String ak2MD5 = "";
                    ak2MD5= MD5password.MD5(ak2);
                    FileWriter writer = new FileWriter(fileName,true);
                    BufferedWriter outWriter=new BufferedWriter(writer);
                    outWriter.write(adName+"&&"+ak1+"&&"+ak2MD5+"&&1");          //�û�����������֤�š����롢�˻�״̬ ��1Ϊ������0Ϊע����
                    outWriter.newLine();
                    outWriter.close();
                    writer.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                //jtn_Name.setText("");
                //jta_text.setText("");
                //jtb_text.setText("");
                JOptionPane.showMessageDialog(null,"ע��ɹ��� ���������ǣ�"+adName+"����֤���ǣ�"+ak1+"��¼�����ǣ�"+ ak2);
                }
                else if(!checkID(ak1))
                {
                    JOptionPane.showMessageDialog(null,"��������֤�Ÿ�ʽ��������������");
                    jtb_text.setText("");
                }else{
                    JOptionPane.showMessageDialog(null,"ע��ʧ�ܣ�������ע��");
                }
                
                
            }
        });
        btn_land.addActionListener(new ActionListener() {
            @SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
            	               jtn_Name.setText("");
                               jta_text.setText("");
                               jtb_text.setText("");
                        }
 
        });
         
         btn_back.addActionListener(new ActionListener() {
            @SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
            	              dispose();
                        }
 
        });
        init();
         
        panel = new MyPanel();
        //�����е�������ӵ�panel�����
        panel.add(lan_Name);
        panel.add(btn_back);
        panel.add(lab_zhanghao);
        panel.add(lat_password);
        panel.add(jtn_Name);
        panel.add(jta_text);
        panel.add(jtb_text);
        panel.add(btn_register);
        panel.add(btn_land);
        panel.setLayout(null);
         
        getContentPane().add(panel);
    }
    private void init() {
        
        lan_Name.setSize(100,50);
        lan_Name.setLocation(100,10);
        lan_Name.setFont(lat);
        lab_zhanghao.setSize(200,50);
        lab_zhanghao. setLocation(50,65);
        lab_zhanghao.setFont(lab);
        lat_password.setSize(200,50);
        lat_password.setLocation(50,115);
        lat_password.setFont(lat);
        jtn_Name.setSize(190,30);
        jtn_Name.setLocation(160,20);
        jta_text.setSize(190,30);
        jta_text.setLocation(160,75);
        jtb_text.setSize(190,30);
        jtb_text.setLocation(160,125);
        btn_register.setSize(120, 40);
        btn_register.setLocation(60, 180);
        btn_land.setSize(120, 40);
        btn_land.setLocation(230, 180);
        btn_register.setFont(btn);
        btn_land.setFont(btn);
        btn_back.setBounds(5, 5, 90, 45);
    }

}
