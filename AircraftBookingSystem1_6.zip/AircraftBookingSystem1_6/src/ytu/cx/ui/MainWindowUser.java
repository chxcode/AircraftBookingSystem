/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ytu.cx.ui;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.text.Collator;
import java.text.ParseException;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import static java.util.Arrays.sort;
import java.util.Comparator;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableColumn;
import ytu.cx.io.FileIOImp;
import ytu.cx.store.CityNode;
import ytu.cx.store.HangBan;
import ytu.cx.util.DateChooser;
import ytu.cx.util.Tool;

import ytu.edu.server.Operation;
/**
 *
 * @author changxuan
 */

public class MainWindowUser extends JFrame {
    static int n=0;
    JScrollPane scroll;  

    private JButton buttonThroughCustomer = new JButton("�ҵĶ�Ʊ��¼");
    //private JButton buttonZhuJieMian_2 = new JButton("������");
    private MainMyPanel cardPane = new MainMyPanel();                //��ײ����
    private MainMyPanel MainPane = new MainMyPanel();                //������
    private MainMyPanel luRuXinXiPane = new MainMyPanel();          //¼����Ϣ
    private MainMyPanel xiuGaiXinXiPane= new MainMyPanel();          //�޸���Ϣ
    private MainMyPanel throughCustomerPane = new MainMyPanel();         //�ͻ�����
    private static final String MainCard = "������";
    private static final String LuRuXinXiCard = "¼����Ϣ";
    private static final String XiuGaiXinXiCard = "�޸���Ϣ";
    private static final String ThroughCustomerCard = "�ҵĶ�Ʊ��¼";
    
    /*-------------------------������ؼ���ʼ��-----------------------------*/
    Date now=new Date();
    SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");	
    JComboBox comboBox,comboBoxZhongDian,comboBoxHangBan;
    int ci;                                                   // listCitys  ������±�ֵ
    DateChooser dateChooser1 = DateChooser.getInstance("yyyy-MM-dd");
    
    private JTextField textRiQi=new JTextField(sdf.format(now));
    private JButton buttonInquiry=new JButton("��ѯ"),buttonBooking=new JButton("��Ʊ"),
            buttonReturnToTicket=new JButton("��Ʊ"),buttonChange=new JButton("��");
    private JLabel title=new JLabel("��ӭʹ����𺽿ն�Ʊϵͳ"),qiDian=new JLabel("������"),
            zhongDian=new JLabel("���"),riQi=new JLabel("ʱ�䣺"),hangBan=new JLabel("���ࣺ"),chaXunJieGuo=new JLabel("��ѯ�����");
    private JTextArea result=new JTextArea("��ѯ���",28,6);
    private JScrollPane resultBian= new JScrollPane(result);
    private Container contentPane = this.getContentPane();
    Font biaoTi = new Font("����",1,30);
    Font zhengWen=new Font("����",1,15);
    Font jieGuo=new Font("����",1,15);

    
    /*--------------------------�ͻ����Ͻ���ؼ���ʼ��-----------------------*/
    private JLabel 
            throughCustomerTitle = new JLabel("�ҵĶ�Ʊ��¼");
    
    private JTextArea resultCustomer=new JTextArea(700,300);
    private JScrollPane resultBianCustomer= new JScrollPane(resultCustomer);
    private JButton 
            buttonZhuJieMian_3 = new JButton("����");
    private CardLayout cardLayout = new CardLayout();

    public MainWindowUser(String userName,String password,String username) {
        String[] listCitys={};     //��city�ļ��� ���ж�ȡ��������
        String[] listHangBan={};
        listHangBan=readHangBan("./flight_information/","flight_record.txt");// �������ļ���ȡ��������
        listCitys=readToCity("./city/","citys.txt");     //��city�ļ��� ���ж�ȡ��������
        Comparator c = Collator.getInstance(Locale.CHINA);
        Arrays.sort(listCitys,c);
       Arrays.sort(listHangBan);
    /*�����������յ�ؼ��ͺ���*/
    comboBox = new JComboBox(listCitys);               //���
    comboBoxZhongDian = new JComboBox(listCitys);      //�յ�
    comboBoxHangBan = new JComboBox(listHangBan);     //�����
    Operation o = new Operation();
    init();                              //���Ž��� �ռ䲼�ֺ���
   
    cardPane.setLayout(cardLayout);
    //MainCard �Ƕ�Ӧ MainPane �ı�ǣ�Ҫͨ��������л�����
    cardPane.add(MainPane, MainCard);
    //LuRuXinXiCard �Ƕ�Ӧ luRuXinXiPane �ı�ǣ�Ҫͨ��������л�����
    cardPane.add(luRuXinXiPane, LuRuXinXiCard);
    //XiuGaiXinXiCard �Ƕ�Ӧ xiuGaiXinXiPane �ı�ǣ�Ҫͨ��������л�����
    cardPane.add(xiuGaiXinXiPane,XiuGaiXinXiCard);
    //�л����û����Ͻ���
    cardPane.add(throughCustomerPane,ThroughCustomerCard);
    
   
   
    /*----------------------------���ӿؼ���������----------------------------- */
  
    //MainPane.setBackground(Color.CYAN);
 
    MainPane.add(title);
    MainPane.add(buttonInquiry);
    MainPane.add(buttonBooking);
    MainPane.add(buttonChange);
    MainPane.add(buttonReturnToTicket);
    MainPane.add(comboBoxHangBan);
    MainPane.add(buttonThroughCustomer);
    MainPane.add(qiDian);
    MainPane.add(zhongDian);
    MainPane.add(hangBan);
    MainPane.add(riQi);
    comboBox.setEditable(true);             //�������еĳ�������ؼ��ɱ༭
    MainPane.add(comboBox);
    comboBoxZhongDian.setEditable(true);
    MainPane.add(comboBoxZhongDian);
    //MainPane.add(textHangBanHao);
    dateChooser1.register(textRiQi);
    MainPane.add(textRiQi);
    MainPane.add(resultBian);
    MainPane.setLayout(null);
   
   // getContentPane().add(MainPane);
    
    
  /*--------------------------���ӿؼ����û����Ͻ���------------------------- */
  throughCustomerPane.add(throughCustomerTitle);
  //throughCustomerPane.add(resultBianCustomer);
  throughCustomerPane.add(buttonZhuJieMian_3);
  throughCustomerPane.setLayout(null);
  
  
  /*����ť�����¼�*/
  
  buttonChange.addActionListener(new ActionListener(){
      @Override
      public void actionPerformed(ActionEvent e){
          String  temp="";
          temp=comboBox.getSelectedItem().toString();
          comboBox.setSelectedItem(comboBoxZhongDian.getSelectedItem());
          comboBoxZhongDian.setSelectedItem(temp);
      }
  });
  
 
  /**
   * ��Ʊ��ť
   */
    buttonReturnToTicket.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            int judge=0;   //�ж��Ƿ�Ʊ
            String lineStrings="";
            String fileStrings="";
            try{
                File files = new File("./booking_record/booking.txt");
                FileReader frs = new FileReader(files);
                BufferedReader brs = new BufferedReader(frs);
                while((lineStrings=brs.readLine())!=null){
                    
                    String[] lineArrays = lineStrings.split("--");
                    if(lineArrays[2].equals(comboBoxHangBan.getSelectedItem())&&lineArrays[1].equals(userName)&&textRiQi.getText().equals(lineArrays[3])&&judge!=1&&lineArrays[5].equals("1")){
                        int ns = Integer.parseInt(lineArrays[5]);
                        ns--;
                        judge=1;  //�Ѷ�
                        lineArrays[5]=""+ns;
                        fileStrings=fileStrings+lineArrays[0]+"--"+lineArrays[1]+"--"+lineArrays[2]+"--"+lineArrays[3]+"--"+lineArrays[4]+"--"+lineArrays[5]+"\n";
                        
                    }
                    else
                        fileStrings=fileStrings+lineStrings+"\n";
                }
                
            }catch(Exception ess){
                ess.printStackTrace();
            }
           //���޸ĺ�����ݴ浽�ļ���
            FileIOImp.write("./booking_record/", fileStrings, false, "booking.txt");
            if(judge==1){
                String lineString="";
                String fileString="";
                try{
                
                File file = new File("./month_flight_information/"+textRiQi.getText()+".txt");
                FileReader fr = new FileReader(file);
                BufferedReader br = new BufferedReader(fr);
                while((lineString=br.readLine())!=null){
                    
                    String[] lineArray = lineString.split("-");
                    if(lineArray[0].equals(comboBoxHangBan.getSelectedItem())){
                        int n = Integer.parseInt(lineArray[2]);
                        n++;
                        lineArray[2]=""+n;
                        fileString=fileString+lineArray[0]+"-"+lineArray[1]+"-"+lineArray[2]+"-"+lineArray[3]+"-"+lineArray[4]+"-"+lineArray[5]+"-"+lineArray[6]+"-"+lineArray[7]+"\n";
                        
                    }
                    else
                        fileString=fileString+lineString+"\n";
                }
                
               }catch(Exception ess){
                 ess.printStackTrace();
               }
            //���޸ĺ�����ݴ浽�ļ���
           
            FileIOImp.write("./month_flight_information/", fileString, false, textRiQi.getText()+".txt");
            JOptionPane.showMessageDialog(null,"��Ʊ�ɹ�����л����ʹ�ã�");

            }
            else{
              JOptionPane.showMessageDialog(null,"��δ��Ʊ������ʧ��");

            }
            //�Ƚ�Ʊ����һ
            
            //2.Ȼ��ȥ�޸�booking.txt �е�����
            
        }
    });
  /**
   * ��Ʊ��ť
   */
   buttonBooking.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            if(!comboBoxHangBan.getSelectedItem().equals("")&&!textRiQi.getText().equals("")){
                 String[] citys = readToCity("./city/","citys.txt");
                 CityNode citynode = new CityNode(citys);
                 readToGraph("./month_flight_information/",textRiQi.getText()+".txt",citynode);
                 JOptionPane.showMessageDialog(null,citynode.DingPiao(comboBoxHangBan.getSelectedItem().toString()));
                 //��ͼ�ṹ�е������ٷŵ��ļ���
                 citynode.storeToFile(textRiQi.getText()+".txt");
                 int state=1;
                 String customerRecond="";
                 customerRecond = username+"--"+userName+"--"+comboBoxHangBan.getSelectedItem().toString()+"--"+textRiQi.getText()+"--"+Tool.getDingDanID(comboBoxHangBan.getSelectedItem().toString())+"--"+state+"\n";
                 //����¼д�뵽booking.txt�ļ���ȥ
                 FileIOImp.write("./booking_record/", customerRecond, true, "booking.txt");
                 
            }
               
            else
                 JOptionPane.showMessageDialog(null,"��ȷ������������ںͺ���ź��ٽ��ж�Ʊ��");
        }
    });
   
    /**
     * ��ѯ��ť
     */
    buttonInquiry.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            //����ʱ���ҵ��洢���ݵ�txt�ļ�
          if(textRiQi.getText().equals(Tool.getTime())){
               JOptionPane.showMessageDialog(null,"Ҫ������Ʊѽ��\nǧ��׼���ʱ��Ӵ��\n��Ȼ�Ϳ��������Ϸɻ��ˣ�");

           }
           else if(Tool.compare_date(Tool.getTime(),textRiQi.getText())){
               JOptionPane.showMessageDialog(null,"��ѡ��������Ѿ������ˣ��������Ǵ�Խ���İɣ�\n�����ǣ�"+Tool.getTime()+" ��������ѡ��һ���ɣ�");
               return ;
          }
           String[] citys = readToCity("./city/","citys.txt");
           CityNode citynode = new CityNode(citys);
           readToGraph("./month_flight_information/",textRiQi.getText()+".txt",citynode);
           String line="\n************************************\n";
           if(!comboBox.getSelectedItem().equals("") && comboBoxZhongDian.getSelectedItem().equals("") && comboBoxHangBan.getSelectedItem().equals("")){ //��ֻ�������ʱ���յ� �ͺ����Ϊ��ʱ ��ʾ�˵صĺ�����Ϣ
               result.setText(citynode.depthFirstTravel(comboBox.getSelectedItem().toString()));
           }else if(comboBoxHangBan.getSelectedItem().equals(""))       //�������յ�����ʱ ��ѯ���ؼ�ĺ���
              result.setText(citynode.judgeThrough(comboBox.getSelectedItem().toString(), comboBoxZhongDian.getSelectedItem().toString())+line+citynode.dijkstraTime(comboBox.getSelectedItem().toString(), comboBoxZhongDian.getSelectedItem().toString())+line+citynode.dijkstraPrice(comboBox.getSelectedItem().toString(), comboBoxZhongDian.getSelectedItem().toString()));
           else{                                              // ��ѯ�����
               result.setText(result.getText()+"\n"+citynode.InquiryHangBan(comboBoxHangBan.getSelectedItem().toString()));
               comboBoxHangBan.setSelectedItem("");
           }
        }
    });
   

    
    //�л���������
    buttonZhuJieMian_3.addActionListener(new ActionListener() {   

    @Override
    public void actionPerformed(ActionEvent e) {
    //ͨ�� MainCard ����л��� MainPane
    scroll.setVisible(false);

    cardLayout.show(cardPane, MainCard);
    }
    });
    //�л����鿴�ͻ�����
    buttonThroughCustomer.addActionListener(new ActionListener() {

    @Override
     
    public void actionPerformed(ActionEvent e) {
    //ͨ�� MainCard ����л��� MainPane
    
    if(true){
        
        cardLayout.show(cardPane, ThroughCustomerCard);
        String[] columnNames =  { "����", "֤����", "����", "��������", "�������", "״̬" };  
        int length = Tool.readToLines("./booking_record/", "booking.txt");
           
        /* 
         * ��ʼ��JTable��������ֵ
         */  
        Object[][] obj = new Object[length][6];  
        String lineString="";
        int i=0,j=0;
	try {
	//�������System.out.println("�ļ���"+filename);
		File  file=new File("./booking_record/"+"booking.txt");
		FileReader fr =new FileReader(file);
	        BufferedReader br=new BufferedReader(fr);
		while((lineString=br.readLine())!=null){
                    
	        String[] lineArray= lineString.split("--");
                if(!lineArray[1].equals(userName)||lineArray[5].equals("0")){
                    continue;
                }
                for ( j = 0; j < 6; j++)  
                {  
                
                switch (j)  
                {  
                case 0:  
                    obj[i][j] = lineArray[0];  
                    break;  
                case 1:  
                    obj[i][j] = lineArray[1];  
                    break;  
                case 2:  
                    obj[i][j] = lineArray[2];  
                    break;  
                case 3:  
                    obj[i][j] = lineArray[3];  
                    break;  
                case 4:  
                    obj[i][j] = lineArray[4];  
                    break;  
                case 5:  
                    if(lineArray[5].equals("1"))
                       obj[i][j] = "����";  
                    else 
                       obj[i][j] = "����Ʊ";
                    break;  
                }  
                }
                i++;
	}
		fr.close();
		br.close();
	} catch (Exception es) {
		es.printStackTrace();
	}
	
	
   
          
          
        /* 
         * JTable������һ�ֹ��췽�� 
         */  
        JTable table = new JTable(obj, columnNames);  
        /* 
         * ����JTable����Ĭ�ϵĿ��Ⱥ͸߶� 
         */  
        TableColumn column = null;  
        int colunms = table.getColumnCount();  
        for(i = 0; i < colunms; i++)  
        {  
            column = table.getColumnModel().getColumn(i);  
            /*��ÿһ�е�Ĭ�Ͽ�������Ϊ100*/  
            if(i==1)
                column.setPreferredWidth(160);
            else if(i==2)
                column.setPreferredWidth(90);
            else if(i==4)
                column.setPreferredWidth(200);
            else 
                column.setPreferredWidth(100);  
        }  
        /* 
         * ����JTable�Զ������б���״̬���˴�����Ϊ�ر� 
         */  
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);  
        table.invalidate();
        /*��JScrollPaneװ��JTable������������Χ���оͿ���ͨ�����������鿴*/  
        scroll = new JScrollPane(table);  
        
        scroll.setSize(700, 250);  
        scroll.setLocation(16, 100);
       
       throughCustomerPane.add(scroll);

      
        
     
    }
    
    
    else
    JOptionPane.showMessageDialog(null,"�����ǹ���Ա��û���޸�Ȩ�ޣ�");
    }
    });
    //�л����޸���Ϣ����
     
    add(cardPane);               //���ӵײ����
    setSize(732,515);
    setTitle("�ɻ���Ʊϵͳ"+"----��ӭ�û���"+userName+"ʹ�ö�Ʊϵͳ");
    this.setLocationRelativeTo(null);
        
    setIconImage(new ImageIcon("./image/Plane.png").getImage());
    setVisible(true);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setResizable(false);
    }
    private void init(){
      /*----------------------------������ؼ�����-------------------------*/
       title.setSize(400,50);
       title.setLocation(186, 20);
       title.setFont(biaoTi);
       buttonInquiry.setSize(80,40);
       buttonInquiry.setLocation(100,230);
       buttonBooking.setSize(80, 40);
       buttonBooking.setLocation(202,230);
       buttonReturnToTicket.setSize(80,40);
       buttonReturnToTicket.setLocation(305, 230);
      
       buttonThroughCustomer.setSize(110,40);
       buttonThroughCustomer.setLocation(100,300);
      
       qiDian.setSize(60,40);
       qiDian.setLocation(60,80);
       qiDian.setFont(zhengWen);
       zhongDian.setSize(60,40);
       zhongDian.setLocation(260,80);
       zhongDian.setFont(zhengWen);
       hangBan.setSize(60,40);
       hangBan.setLocation(60,160);
       hangBan.setFont(zhengWen);
       riQi.setSize(60,40);
       riQi.setLocation(260,160);
       riQi.setFont(zhengWen);
       comboBoxHangBan.setSize(100,40);
       comboBoxHangBan.setLocation(100,160);

       comboBox.setSize(80,40);
       comboBox.setLocation(100,80);
       buttonChange.setSize(60,35);
       buttonChange.setLocation(190,85);
       buttonChange.setForeground(Color.blue);
       comboBoxZhongDian.setSize(80,40);
       comboBoxZhongDian.setLocation(300,80);
      
       textRiQi.setSize(90,40);
       textRiQi.setLocation(300,160);
       chaXunJieGuo.setSize(140,30);
       chaXunJieGuo.setLocation(60,300);
       chaXunJieGuo.setFont(jieGuo);
       result.setEditable(false);
       resultBian.setBounds(410, 80,330, 250);
       
       /*----------------------------¼�뺽����Ϣ����ؼ�����----------------------*/
      
       
       
       /*----------------------------�ͻ����Ͻ���ؼ�����----------------------*/
       throughCustomerTitle.setSize(200,50);
       throughCustomerTitle.setLocation(275,15);
       throughCustomerTitle.setFont(biaoTi);
       resultBianCustomer.setSize(700,250);
       resultBianCustomer.setLocation(16,100);
       buttonZhuJieMian_3.setSize(80,40);
       buttonZhuJieMian_3.setLocation(20,10);
    }
    public static void readToGraph(String FILEPATH,String filename,CityNode citynode) {
		String lineString="";
                String[] aircraftArray = new String[8];
		try {
			//�������System.out.println("�ļ���"+filename);
			File  file=new File(FILEPATH+filename);
			FileReader fr =new FileReader(file);
			BufferedReader br=new BufferedReader(fr);
			while((lineString=br.readLine())!=null){
				aircraftArray = lineString.split("-");
                             double luPrice=Double.parseDouble(aircraftArray[1]);
                             int    luZuoWei = Integer.parseInt(aircraftArray[2]);
                             HangBan hangban8 = new HangBan(aircraftArray[0],luPrice,luZuoWei,aircraftArray[3],aircraftArray[4],aircraftArray[5]);
                             citynode.addEdge(aircraftArray[6], aircraftArray[7], hangban8);
			}
			fr.close();
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    /**
     * ���ļ��еĳ��ж��뵽������ ������
     * @param FILEPATH
     * @param filename
     * @return 
     */
    public static String[] readToCity(String FILEPATH,String filename) {
		String lineString="";
              //String[] aircraftArray = new String[];
		try {
			//�������System.out.println("�ļ���"+filename);
			File  file=new File(FILEPATH+filename);
			FileReader fr =new FileReader(file);
			BufferedReader br=new BufferedReader(fr);
			while((lineString=br.readLine())!=null){
			String[] city = lineString.split("��");
                         return city;   
			}
			fr.close();
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
                return null;
	}
    /**
     * ���洢���ļ��еĺ�����Ϣ�е� ����Ŷ�ȡ��������
     * @param FILEPATH
     * @param filename
     * @return 
     */
    public static String[] readHangBan(String FILEPATH,String filename){
        String[] hangbanArray;
        if(!Tool.testDir(FILEPATH+filename)){
            
            hangbanArray=new String[1];
            hangbanArray[0]="";
             return hangbanArray; 
        }
        String lineString="";
        //�󺽰�����Ŀ
        int hangbanlength=1;
              try {
			File  file=new File(FILEPATH+filename);
			FileReader fr =new FileReader(file);
			BufferedReader br=new BufferedReader(fr);
			while((lineString=br.readLine())!=null){
			       hangbanlength++;
			}
			fr.close();
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
                }
              // ������Ÿ��Ƶ�������
        hangbanArray =new String[hangbanlength];
        
        hangbanArray[0]="";
		try {
			File  file=new File(FILEPATH+filename);
			FileReader fr =new FileReader(file);
			BufferedReader br=new BufferedReader(fr);
                        int i=1;
			while((lineString=br.readLine())!=null){
			String[] city = lineString.split("-");
                           hangbanArray[i]=city[0];
                           i++;
			}
			fr.close();
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
                return hangbanArray;
    }
   

}

