/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ytu.cx.ui;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableColumn;
import ytu.cx.io.FileIOImp;
import ytu.cx.store.CityNode;
import ytu.cx.store.HangBan;
import ytu.cx.util.Tool;
import ytu.edu.server.Operation;
/**
 *
 * @author changxuan
 */

public class MainWindow extends JFrame {
    static int n=0;
    JScrollPane scroll;  

    private JButton buttonLuRuXinXi = new JButton("¼�뺽����Ϣ");
    private JButton buttonThroughCustomer = new JButton("�ͻ���Ʊ��¼");
    //private JButton buttonZhuJieMian_2 = new JButton("������");
    private JButton buttonXiuGaiXinXi = new JButton("�޸ĺ�����Ϣ");
    private MainMyPanel cardPane = new MainMyPanel();                //��ײ����
    private MainMyPanel MainPane = new MainMyPanel();                //������
    private MainMyPanel luRuXinXiPane = new MainMyPanel();          //¼����Ϣ
    private MainMyPanel xiuGaiXinXiPane= new MainMyPanel();          //�޸���Ϣ
    private MainMyPanel throughCustomerPane = new MainMyPanel();         //�ͻ�����
    private static final String MainCard = "������";
    private static final String LuRuXinXiCard = "¼����Ϣ";
    private static final String XiuGaiXinXiCard = "�޸���Ϣ";
    private static final String ThroughCustomerCard = "�ͻ���Ʊ��¼";
    
    /*-------------------------������ؼ���ʼ��-----------------------------*/
    Date now=new Date();
    SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");	
    private JTextField textQiDian=new JTextField(),textZhongDian=new JTextField(),
            textHangBanHao=new JTextField(),textRiQi=new JTextField(sdf.format(now));
    private JButton buttonInquiry=new JButton("��ѯ"),buttonBooking=new JButton("��Ʊ"),
            buttonReturnToTicket=new JButton("��Ʊ"),buttonChange=new JButton("C");
    private JLabel title=new JLabel("��ӭʹ����𺽿ն�Ʊϵͳ"),qiDian=new JLabel("������"),
            zhongDian=new JLabel("���"),riQi=new JLabel("ʱ�䣺"),hangBan=new JLabel("���ࣺ"),chaXunJieGuo=new JLabel("��ѯ�����");
    private JTextArea result=new JTextArea("��ѯ���",28,6);
    private JScrollPane resultBian= new JScrollPane(result);
    private Container contentPane = this.getContentPane();
    Font biaoTi = new Font("����",1,30);
    Font zhengWen=new Font("����",1,15);
    Font jieGuo=new Font("����",1,15);
    /*--------------------------¼�뺽����Ϣ����ؼ���ʼ��-----------------------*/
    private JLabel 
            textTitleLuRuXinXi = new JLabel("¼�뺽����Ϣ"),
            textChuFa = new JLabel("������"),
            textDaoDa = new JLabel("���"),
            textHangBan = new JLabel("���ࣺ"),
            textJiaGe = new JLabel("�۸�"),
            textZuoWeiNumber = new JLabel("��λ��"),
            textZheKou = new JLabel("�ۿۣ�"),
            textQiFeiTime = new JLabel("���ʱ�䣺"),
            textLandTime = new JLabel("����ʱ�䣺"),
            textGeshi1 = new JLabel("����12:30:00");
             
    private JTextField chuFa = new JTextField(),
                       daoDa = new JTextField(),
                       hangBanHao = new JTextField(),
                       jiaGe = new JTextField(),
                       zuoWeiNumber = new JTextField(),
                       zheKou = new JTextField(),
                       qiFeiTime = new JTextField(),
                       landTime = new JTextField();
    private JButton
            buttonZhuJieMian_1 = new JButton("����"),
            luRuButton = new JButton("ȷ��¼��");
    
    /*--------------------------�޸ĺ�����Ϣ����ؼ���ʼ��-----------------------*/
    private JLabel 
            textZhuyi =new JLabel("ע���޸ĺ����Ϣ����һ���º���Ч"),
            textTitleXiuGaiXinXi = new JLabel("�޸ĺ�����Ϣ"),
            textShuoMing1 = new JLabel("--�����޸ĺ����:"),
            textshuoMing2 = new JLabel("--�������޸���Ϣ:"),
            textHangBanXiuGai = new JLabel("���ࣺ"),
            textJiaGeXiuGai = new JLabel("�۸�"),
            textZuoWeiNumberXiuGai = new JLabel("��λ��"),
            textZheKouXiuGai = new JLabel("�ۿۣ�"),
            textQiFeiTimeXiuGai = new JLabel("���ʱ�䣺"),
            textLandTimeXiuGai = new JLabel("����ʱ�䣺")
             ;
    private JTextField 
                       hangBanHaoXiuGai = new JTextField(),
                       jiaGeXiuGai = new JTextField(),
                       zuoWeiNumberXiuGai = new JTextField(),
                       zheKouXiuGai = new JTextField(),
                       qiFeiTimeXiuGai = new JTextField(),
                       landTimeXiuGai = new JTextField();
    private JButton
            buttonZhuJieMian_2 = new JButton("����"),
            xiuGaiButton = new JButton("ȷ���޸�");
    /*--------------------------�ͻ����Ͻ���ؼ���ʼ��-----------------------*/
    private JLabel 
            throughCustomerTitle = new JLabel("�ͻ���Ʊ��¼");
    
    private JTextArea resultCustomer=new JTextArea(700,300);
    private JScrollPane resultBianCustomer= new JScrollPane(resultCustomer);
    private JButton 
            buttonZhuJieMian_3 = new JButton("����");
    private CardLayout cardLayout = new CardLayout();

    public MainWindow(String userName,String password,String username) {
    Operation o = new Operation();
    init();                              //���Ž��� �ռ䲼�ֺ���
   /*
        String[] citys = {"��̨","�Ϻ�","����","�㶫","����"};
        CityNode citynode = new CityNode(citys);
        System.out.println("�����������");
        HangBan hangban1=new HangBan("YS3213",2,12,"����","13:30:00","15:30:00");
        citynode.addEdge("��̨", "�Ϻ�", hangban1);
        HangBan hangban2=new HangBan("YJ3212",1,12,"����","13:30:00","14:30:00");
        citynode.addEdge("��̨", "����", hangban2);
        HangBan hangban3=new HangBan("YG3213",5,12,"����","13:30:00","18:30:00");
        citynode.addEdge("��̨", "�㶫", hangban3);
        HangBan hangban4=new HangBan("JJ3213",3,12,"����","14:30:00","17:30:00");
        citynode.addEdge("����", "����", hangban4);
        HangBan hangban5=new HangBan("SG3213",2,12,"����","13:30:00","15:30:00");
        citynode.addEdge("�Ϻ�", "�㶫", hangban5);
        HangBan hangban6=new HangBan("GJ3213",8,12,"����","13:30:00","21:30:00");
        citynode.addEdge("�㶫", "����", hangban6);
        HangBan hangban7=new HangBan("JY3213",8,12,"����","13:30:00","21:30:00");
        citynode.addEdge("����", "��̨", hangban7);
         citynode.dijkstraTime("����", "��̨");
        citynode.dijkstraPrice("����", "��̨");
        citynode.dijkstraTime("��̨", "����");
        citynode.dijkstraPrice("��̨", "����");
    */
    cardPane.setLayout(cardLayout);
    //MainCard �Ƕ�Ӧ MainPane �ı�ǣ�Ҫͨ��������л�����
    cardPane.add(MainPane, MainCard);
    //LuRuXinXiCard �Ƕ�Ӧ luRuXinXiPane �ı�ǣ�Ҫͨ��������л�����
    cardPane.add(luRuXinXiPane, LuRuXinXiCard);
    //XiuGaiXinXiCard �Ƕ�Ӧ xiuGaiXinXiPane �ı�ǣ�Ҫͨ��������л�����
    cardPane.add(xiuGaiXinXiPane,XiuGaiXinXiCard);
    //�л����û����Ͻ���
    cardPane.add(throughCustomerPane,ThroughCustomerCard);
    
   
   
    /*----------------------------���ӿؼ���������----------------------------- */
  
    //MainPane.setBackground(Color.CYAN);
    
    MainPane.add(title);
    MainPane.add(buttonInquiry);
    MainPane.add(buttonBooking);
    MainPane.add(buttonChange);
    MainPane.add(buttonReturnToTicket);
    MainPane.add(buttonLuRuXinXi);
    MainPane.add(buttonXiuGaiXinXi);
    MainPane.add(buttonThroughCustomer);
    MainPane.add(qiDian);
    MainPane.add(zhongDian);
    MainPane.add(hangBan);
    MainPane.add(riQi);
    MainPane.add(textQiDian);
    MainPane.add(textZhongDian);
    MainPane.add(textHangBanHao);
    MainPane.add(textRiQi);
    MainPane.add(resultBian);
    MainPane.setLayout(null);
   // getContentPane().add(MainPane);
    /*--------------------------���ӿؼ���¼�뺽����Ϣ����------------------------- */
    luRuXinXiPane.add(buttonZhuJieMian_1);
    luRuXinXiPane.add(textTitleLuRuXinXi);
    luRuXinXiPane.add(textChuFa);
    luRuXinXiPane.add(textDaoDa);
    luRuXinXiPane.add(textJiaGe);
    luRuXinXiPane.add(textHangBan);
    luRuXinXiPane.add(chuFa);
    luRuXinXiPane.add(daoDa);
    luRuXinXiPane.add(hangBanHao);
    luRuXinXiPane.add(jiaGe);
    luRuXinXiPane.add(textGeshi1);
    
    luRuXinXiPane.add(textZuoWeiNumber);
    luRuXinXiPane.add(textZheKou);
    luRuXinXiPane.add(textQiFeiTime);
    luRuXinXiPane.add(textLandTime);
    luRuXinXiPane.add(zuoWeiNumber);
    luRuXinXiPane.add(zheKou);
    luRuXinXiPane.add(qiFeiTime);
    luRuXinXiPane.add(landTime);
    luRuXinXiPane.add(luRuButton);
    
    luRuXinXiPane.setLayout(null);
    
    
    /*--------------------------���ӿؼ����޸ĺ�����Ϣ����------------------------- */
    xiuGaiXinXiPane.add(buttonZhuJieMian_2);
    xiuGaiXinXiPane.add(textZhuyi);
    xiuGaiXinXiPane.add(textTitleXiuGaiXinXi);
    xiuGaiXinXiPane.add(textHangBanXiuGai);
    xiuGaiXinXiPane.add(textShuoMing1);
    xiuGaiXinXiPane.add(textshuoMing2);
    xiuGaiXinXiPane.add(textJiaGeXiuGai);
    
    xiuGaiXinXiPane.add(hangBanHaoXiuGai);
    xiuGaiXinXiPane.add(jiaGeXiuGai);
    
    xiuGaiXinXiPane.add(textZuoWeiNumberXiuGai);
    xiuGaiXinXiPane.add(textZheKouXiuGai);
    xiuGaiXinXiPane.add(textQiFeiTimeXiuGai);
    xiuGaiXinXiPane.add(textLandTimeXiuGai);
    xiuGaiXinXiPane.add(zuoWeiNumberXiuGai);
    xiuGaiXinXiPane.add(zheKouXiuGai);
    xiuGaiXinXiPane.add(qiFeiTimeXiuGai);
    xiuGaiXinXiPane.add(landTimeXiuGai);
    xiuGaiXinXiPane.add(xiuGaiButton);
    
    xiuGaiXinXiPane.setLayout(null);
    
  //  xiuGaiXinXiPane.setLayout(null);
    
  /*--------------------------���ӿؼ����û����Ͻ���------------------------- */
  throughCustomerPane.add(throughCustomerTitle);
  //throughCustomerPane.add(resultBianCustomer);
  throughCustomerPane.add(buttonZhuJieMian_3);
  throughCustomerPane.setLayout(null);
  
  
  /*����ť�����¼�*/
  
  buttonChange.addActionListener(new ActionListener(){
      @Override
      public void actionPerformed(ActionEvent e){
          String temp="";
          temp=textQiDian.getText();
          textQiDian.setText(textZhongDian.getText());
          textZhongDian.setText(temp);
      }
  });
  
  /**
   * �޸ĺ�����Ϣ��ť�¼�
   */
  xiuGaiButton.addActionListener(new ActionListener(){
      @Override
      public void actionPerformed(ActionEvent e){
          int judge=0;
          String lineString ="";
          String fileString ="";
          try{
              File file = new File("./flight_information/flight_record.txt");
              FileReader fr = new FileReader(file);
              BufferedReader br= new BufferedReader(fr);
              while((lineString=br.readLine())!=null){
                  String[] lineArray= lineString.split("-");
                  if(lineArray[0].equals(hangBanHaoXiuGai.getText())){
                      judge=1;
                      lineArray[1]=jiaGeXiuGai.getText();
                      lineArray[2]= zuoWeiNumberXiuGai.getText();
                      lineArray[3]=zheKouXiuGai.getText();
                      lineArray[4]= qiFeiTimeXiuGai.getText();
                      lineArray[5]= landTimeXiuGai.getText();
                      fileString=fileString+lineArray[0]+"-"+lineArray[1]+"-"+lineArray[2]+"-"+lineArray[3]+"-"+lineArray[4]+"-"+lineArray[5]+"-"+lineArray[6]+"-"+lineArray[7]+"\n";
                  }else
                      fileString=fileString+lineString+"\n";
              }
          }catch(Exception ess){
              ess.printStackTrace();
          }
          FileIOImp.write("./flight_information/", fileString, false, "flight_record.txt");

          if(judge==1){
                JOptionPane.showMessageDialog(null,"�޸ĳɹ���");

          }
          else{
                JOptionPane.showMessageDialog(null,"�޴˺��࣬��ȷ�Ϻ��ٽ����޸ģ�");

          }
      }
  });
  /**
   * ��Ʊ��ť
   */
    buttonReturnToTicket.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            int judge=0;   //�ж��Ƿ�Ʊ
            String lineStrings="";
            String fileStrings="";
            try{
                File files = new File("./booking_record/booking.txt");
                FileReader frs = new FileReader(files);
                BufferedReader brs = new BufferedReader(frs);
                while((lineStrings=brs.readLine())!=null){
                    
                    String[] lineArrays = lineStrings.split("--");
                    if(lineArrays[2].equals(textHangBanHao.getText())&&lineArrays[1].equals(userName)&&textRiQi.getText().equals(lineArrays[3])){
                        int ns = Integer.parseInt(lineArrays[5]);
                        ns--;
                        judge=1;  //�Ѷ�
                        lineArrays[5]=""+ns;
                        fileStrings=fileStrings+lineArrays[0]+"--"+lineArrays[1]+"--"+lineArrays[2]+"--"+lineArrays[3]+"--"+lineArrays[4]+"--"+lineArrays[5]+"\n";
                        
                    }
                    else
                        fileStrings=fileStrings+lineStrings+"\n";
                }
                
            }catch(Exception ess){
                ess.printStackTrace();
            }
           //���޸ĺ�����ݴ浽�ļ���
            FileIOImp.write("./booking_record/", fileStrings, false, "booking.txt");
            if(judge==1){
                String lineString="";
                String fileString="";
                try{
                
                File file = new File("./month_flight_information/"+textRiQi.getText()+".txt");
                FileReader fr = new FileReader(file);
                BufferedReader br = new BufferedReader(fr);
                while((lineString=br.readLine())!=null){
                    
                    String[] lineArray = lineString.split("-");
                    if(lineArray[0].equals(textHangBanHao.getText())){
                        int n = Integer.parseInt(lineArray[2]);
                        n++;
                        lineArray[2]=""+n;
                        fileString=fileString+lineArray[0]+"-"+lineArray[1]+"-"+lineArray[2]+"-"+lineArray[3]+"-"+lineArray[4]+"-"+lineArray[5]+"-"+lineArray[6]+"-"+lineArray[7]+"\n";
                        
                    }
                    else
                        fileString=fileString+lineString+"\n";
                }
                
               }catch(Exception ess){
                 ess.printStackTrace();
               }
            //���޸ĺ�����ݴ浽�ļ���
            System.out.println(fileString);
            FileIOImp.write("./month_flight_information/", fileString, false, textRiQi.getText()+".txt");
            JOptionPane.showMessageDialog(null,"��Ʊ�ɹ�����л����ʹ�ã�");

            }
            else{
              JOptionPane.showMessageDialog(null,"��δ��Ʊ������ʧ��");

            }
            //�Ƚ�Ʊ����һ
            
            //2.Ȼ��ȥ�޸�booking.txt �е�����
            
        }
    });
  /**
   * ��Ʊ��ť
   */
   buttonBooking.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            if(!textHangBanHao.getText().equals("")&&!textRiQi.getText().equals("")){
                 String[] citys = readToCity("./city/","citys.txt");
                 CityNode citynode = new CityNode(citys);
                 readToGraph("./month_flight_information/",textRiQi.getText()+".txt",citynode);
                 JOptionPane.showMessageDialog(null,citynode.DingPiao(textHangBanHao.getText()));
                 //��ͼ�ṹ�е������ٷŵ��ļ���
                 citynode.storeToFile(textRiQi.getText()+".txt");
                 int state=1;
                 String customerRecond="";
                 customerRecond = username+"--"+userName+"--"+textHangBanHao.getText()+"--"+textRiQi.getText()+"--"+Tool.getDingDanID(textHangBanHao.getText())+"--"+state+"\n";
                 //����¼д�뵽booking.txt�ļ���ȥ
                 FileIOImp.write("./booking_record/", customerRecond, true, "booking.txt");
                 
            }
               
            else
                 JOptionPane.showMessageDialog(null,"��ȷ������������ںͺ���ź��ٽ��ж�Ʊ��");
        }
    });
    /**
     * ¼�밴ť
     *  
     */
    
  
    luRuButton.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
        if(!hangBanHao.getText().equals("")&&!jiaGe.getText().equals("")&&!zuoWeiNumber.getText().equals("")&&!zheKou.getText().equals("")&&!qiFeiTime.getText().equals("")&&!landTime.getText().equals("")&&!chuFa.getText().equals("")&&!daoDa.getText().equals("")){
            String  recordTxt = hangBanHao.getText()+"-"+jiaGe.getText()+"-"+zuoWeiNumber.getText()+"-"+zheKou.getText()+"-"+qiFeiTime.getText()+"-"
                    +landTime.getText()+"-"+chuFa.getText()+"-"+daoDa.getText()+"\n";
            FileIOImp.write("./flight_information/", recordTxt, true, "flight_record.txt");
            for(int i=0;i<30;i++){
                FileIOImp.write("./month_flight_information/", recordTxt, true,  Tool.getAftertime(i)+".txt");
            }
            JOptionPane.showMessageDialog(null, "¼��ɹ���");
        }else{
            JOptionPane.showMessageDialog(null, "¼����Ϣ����ȷ����ȷ������©��Ϣ�����¼�룡");

        }
           

            /*
             double luPrice=Double.parseDouble(jiaGe.getText());
             int    luZuoWei = Integer.parseInt(zuoWeiNumber.getText());
            
             HangBan hangban1=new HangBan(hangBanHao.getText(),luPrice,luZuoWei,zheKou.getText(),qiFeiTime.getText(),landTime.getText());
             */
            // JOptionPane.showMessageDialog(null,citynode.addEdge(chuFa.getText(), daoDa.getText(), hangban1));
        }
    });
    /**
     * ��ѯ��ť
     */
    buttonInquiry.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){//����ʱ���ҵ��洢���ݵ�txt�ļ�
           // System.out.println(textQiDian.getText()+textZhongDian.getText());
           String[] citys = readToCity("./city/","citys.txt");
           CityNode citynode = new CityNode(citys);
           readToGraph("./month_flight_information/",textRiQi.getText()+".txt",citynode);
           String line="\n************************************\n";
           if(!textQiDian.getText().equals("") && textZhongDian.getText().equals("") && textHangBanHao.getText().equals("")){
               result.setText(citynode.depthFirstTravel(textQiDian.getText()));
           }else if(textHangBanHao.getText().equals(""))
              result.setText(citynode.judgeThrough(textQiDian.getText(), textZhongDian.getText())+line+citynode.dijkstraTime(textQiDian.getText(), textZhongDian.getText())+line+citynode.dijkstraPrice(textQiDian.getText(), textZhongDian.getText()));
           else{
               result.setText(result.getText()+"\n"+citynode.InquiryHangBan(textHangBanHao.getText()));
               textHangBanHao.setText("");
           }
        }
    });
    buttonLuRuXinXi.addActionListener(new ActionListener() {   //�л���¼����Ϣ����

    @Override
    public void actionPerformed(ActionEvent e) {
    //ͨ�� LuRuXinXiCard ����л��� luRuXinXiPane
    
    if(userName.equals("admin")&&password.equals("admin"))
       cardLayout.show(cardPane, LuRuXinXiCard);
    else
      JOptionPane.showMessageDialog(null,"�����ǹ���Ա��û��¼����ϢȨ�ޣ�");
   
    }
    });
    //�л���������
    buttonZhuJieMian_1.addActionListener(new ActionListener() {   

    @Override
    public void actionPerformed(ActionEvent e) {
    //ͨ�� MainCard ����л��� MainPane
    cardLayout.show(cardPane, MainCard);
    }
    });
    //�л���������
    buttonZhuJieMian_2.addActionListener(new ActionListener() {

    @Override
    public void actionPerformed(ActionEvent e) {
    //ͨ�� MainCard ����л��� MainPane
    cardLayout.show(cardPane, MainCard);
    }
    });
    //�л���������
    buttonZhuJieMian_3.addActionListener(new ActionListener() {   

    @Override
    public void actionPerformed(ActionEvent e) {
    //ͨ�� MainCard ����л��� MainPane
    scroll.setVisible(false);

    cardLayout.show(cardPane, MainCard);
    }
    });
    //�л����鿴�ͻ�����
    buttonThroughCustomer.addActionListener(new ActionListener() {

    @Override
     
    public void actionPerformed(ActionEvent e) {
    //ͨ�� MainCard ����л��� MainPane
    
    if(userName.equals("admin")&&password.equals("admin")){
        
        cardLayout.show(cardPane, ThroughCustomerCard);
        String[] columnNames =  { "����", "֤����", "����", "��������", "�������", "״̬" };  
        int length = Tool.readToLines("./booking_record/", "booking.txt");
           
        /* 
         * ��ʼ��JTable��������ֵ
         */  
        Object[][] obj = new Object[length][6];  
        String lineString="";
        int i=0,j=0;
	try {
	//�������System.out.println("�ļ���"+filename);
		File  file=new File("./booking_record/"+"booking.txt");
		FileReader fr =new FileReader(file);
	        BufferedReader br=new BufferedReader(fr);
		while((lineString=br.readLine())!=null){
                    
	        String[] lineArray= lineString.split("--");
                for ( j = 0; j < 6; j++)  
                {  
                
                switch (j)  
                {  
                case 0:  
                    obj[i][j] = lineArray[0];  
                    break;  
                case 1:  
                    obj[i][j] = lineArray[1];  
                    break;  
                case 2:  
                    obj[i][j] = lineArray[2];  
                    break;  
                case 3:  
                    obj[i][j] = lineArray[3];  
                    break;  
                case 4:  
                    obj[i][j] = lineArray[4];  
                    break;  
                case 5:  
                    if(lineArray[5].equals("1"))
                       obj[i][j] = "����";  
                    else 
                       obj[i][j] = "����Ʊ";
                    break;  
                }  
                }
                i++;
	}
		fr.close();
		br.close();
	} catch (Exception es) {
		es.printStackTrace();
	}
	
	
   
          
          
        /* 
         * JTable������һ�ֹ��췽�� 
         */  
        JTable table = new JTable(obj, columnNames);  
        /* 
         * ����JTable����Ĭ�ϵĿ��Ⱥ͸߶� 
         */  
        TableColumn column = null;  
        int colunms = table.getColumnCount();  
        for(i = 0; i < colunms; i++)  
        {  
            column = table.getColumnModel().getColumn(i);  
            /*��ÿһ�е�Ĭ�Ͽ�������Ϊ100*/  
            if(i==1)
                column.setPreferredWidth(160);
            else if(i==2)
                column.setPreferredWidth(90);
            else if(i==4)
                column.setPreferredWidth(200);
            else 
                column.setPreferredWidth(100);  
        }  
        /* 
         * ����JTable�Զ������б���״̬���˴�����Ϊ�ر� 
         */  
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);  
        table.invalidate();
        //table.update();
        //AbstractTableModel model = (AbstractTableModel) table.getModel();
       // model.fireTableDataChanged();
        //table.updateUI();
        /*��JScrollPaneװ��JTable������������Χ���оͿ���ͨ�����������鿴*/  
        scroll = new JScrollPane(table);  
        
        scroll.setSize(700, 250);  
        scroll.setLocation(16, 100);
       
       throughCustomerPane.add(scroll);

      
        
     
    }
    
    
    else
    JOptionPane.showMessageDialog(null,"�����ǹ���Ա��û���޸�Ȩ�ޣ�");
    }
    });
    //�л����޸���Ϣ����
     buttonXiuGaiXinXi.addActionListener(new ActionListener() {

    @Override
    public void actionPerformed(ActionEvent e) {
    //ͨ�� MainCard ����л��� MainPane
    if(userName.equals("admin")&&password.equals("admin"))
      cardLayout.show(cardPane, XiuGaiXinXiCard);
    else
    JOptionPane.showMessageDialog(null,"�����ǹ���Ա��û���޸�Ȩ�ޣ�");
    }
    });
    add(cardPane);               //���ӵײ����
    setSize(732,515);
    setTitle("�ɻ���Ʊϵͳ"+"----��ӭ�û���"+userName+"ʹ�ö�Ʊϵͳ");
    this.setLocationRelativeTo(null);
        
    setIconImage(new ImageIcon("Plane.png").getImage());
    setVisible(true);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setResizable(false);
    }
    private void init(){
      /*----------------------------������ؼ�����-------------------------*/
       title.setSize(400,50);
       title.setLocation(186, 20);
       title.setFont(biaoTi);
       buttonInquiry.setSize(80,40);
       buttonInquiry.setLocation(100,230);
       buttonBooking.setSize(80, 40);
       buttonBooking.setLocation(220,230);
       buttonReturnToTicket.setSize(80,40);
       buttonReturnToTicket.setLocation(340, 230);
       buttonLuRuXinXi.setSize(140,40);
       buttonLuRuXinXi.setLocation(100,300);
       buttonThroughCustomer.setSize(140,40);
       buttonThroughCustomer.setLocation(460,300);
       buttonXiuGaiXinXi.setSize(140,40);
       buttonXiuGaiXinXi.setLocation(280,300);
       qiDian.setSize(60,40);
       qiDian.setLocation(60,80);
       qiDian.setFont(zhengWen);
       zhongDian.setSize(60,40);
       zhongDian.setLocation(280,80);
       zhongDian.setFont(zhengWen);
       hangBan.setSize(60,40);
       hangBan.setLocation(60,160);
       hangBan.setFont(zhengWen);
       riQi.setSize(60,40);
       riQi.setLocation(280,160);
       riQi.setFont(zhengWen);
       textQiDian.setSize(120,30);
       textQiDian.setLocation(120,90);
       buttonChange.setSize(30,30);
       buttonChange.setLocation(240,90);
       textZhongDian.setSize(120,30);
       textZhongDian.setLocation(340,90);
       textHangBanHao.setSize(120,30);
       textHangBanHao.setLocation(120,170);
       textRiQi.setSize(120,30);
       textRiQi.setLocation(340,170);
       chaXunJieGuo.setSize(140,30);
       chaXunJieGuo.setLocation(60,300);
       chaXunJieGuo.setFont(jieGuo);
       result.setEditable(false);
       resultBian.setBounds(470, 80,255, 160);
       
       /*----------------------------¼�뺽����Ϣ����ؼ�����----------------------*/
       textTitleLuRuXinXi.setSize(200, 50);
       textTitleLuRuXinXi.setLocation(255, 15);
       textTitleLuRuXinXi.setFont(biaoTi);
       buttonZhuJieMian_1.setSize(80,40);
       buttonZhuJieMian_1.setLocation(20,10);
       textChuFa.setSize(60, 30);
       textChuFa.setLocation(125, 80);
       textChuFa.setFont(zhengWen);
       textDaoDa.setSize(60, 30);
       textDaoDa.setLocation(125, 135);
       textDaoDa.setFont(zhengWen);
       textHangBan.setSize(60,30);
       textHangBan.setLocation(125,190);
       textHangBan.setFont(zhengWen);
       textJiaGe.setSize(60,30);
       textJiaGe.setLocation(125,245);
       textJiaGe.setFont(zhengWen);
       chuFa.setSize(120,30);
       chuFa.setLocation(185,80);
       daoDa.setSize(120,30);
       daoDa.setLocation(185,135);
       hangBanHao.setSize(120,30);
       hangBanHao.setLocation(185,190);
       jiaGe.setSize(120,30);
       jiaGe.setLocation(185,245);
       
       
       
       textZuoWeiNumber.setSize(60,30);
       textZuoWeiNumber.setLocation(365,80);
       textZuoWeiNumber.setFont(zhengWen);
       textZheKou.setSize(60,30);
       textZheKou.setLocation(365,135);
       textZheKou.setFont(zhengWen);
       textQiFeiTime.setSize(120,30);
       textQiFeiTime.setLocation(365,190);
       textQiFeiTime.setFont(zhengWen);
       textGeshi1.setSize(120,30);
       textGeshi1.setLocation(570, 190);
       textGeshi1.setFont(zhengWen);
       textLandTime.setSize(120,30);
       textLandTime.setLocation(365,245);
       textLandTime.setFont(zhengWen);
       
       zuoWeiNumber.setSize(120,30);
       zuoWeiNumber.setLocation(430,80);
       zheKou.setSize(120,30);
       zheKou.setLocation(430,135);
       qiFeiTime.setSize(120,30);
       qiFeiTime.setLocation(430,190);
       landTime.setSize(120,30);
       landTime.setLocation(430,245);
       luRuButton.setSize(80,40);
       luRuButton.setLocation(300,300);
      
       /*----------------------------�޸ĺ�����Ϣ����ؼ�����----------------------*/
       textZhuyi.setSize(300,30);
       textZhuyi.setLocation(465, 35);
       textZhuyi.setFont(zhengWen);
       textTitleXiuGaiXinXi.setSize(200, 50);
       textTitleXiuGaiXinXi.setLocation(255, 15);
       textTitleXiuGaiXinXi.setFont(biaoTi);
       buttonZhuJieMian_2.setSize(80,40);
       buttonZhuJieMian_2.setLocation(20,10);
       textShuoMing1.setSize(250,30);
       textShuoMing1.setLocation(125, 80);
       textShuoMing1.setFont(zhengWen);
       textHangBanXiuGai.setSize(60, 30);
       textHangBanXiuGai.setLocation(125, 135);
       textHangBanXiuGai.setFont(zhengWen);
       textshuoMing2.setSize(250,30);
       textshuoMing2.setLocation(125,190);
       textshuoMing2.setFont(zhengWen);
       textJiaGeXiuGai.setSize(60,30);
       textJiaGeXiuGai.setLocation(125,245);
       textJiaGeXiuGai.setFont(zhengWen);
       
       
       hangBanHaoXiuGai.setSize(120,30);
       hangBanHaoXiuGai.setLocation(185,135);
       jiaGeXiuGai.setSize(120,30);
       jiaGeXiuGai.setLocation(185,245);
       
       
       
       textZuoWeiNumberXiuGai.setSize(60,30);
       textZuoWeiNumberXiuGai.setLocation(365,80);
       textZuoWeiNumberXiuGai.setFont(zhengWen);
       textZheKouXiuGai.setSize(60,30);
       textZheKouXiuGai.setLocation(365,135);
       textZheKouXiuGai.setFont(zhengWen);
       textQiFeiTimeXiuGai.setSize(120,30);
       textQiFeiTimeXiuGai.setLocation(365,190);
       textQiFeiTimeXiuGai.setFont(zhengWen);
       textLandTimeXiuGai.setSize(120,30);
       textLandTimeXiuGai.setLocation(365,245);
       textLandTimeXiuGai.setFont(zhengWen);
       
       zuoWeiNumberXiuGai.setSize(120,30);
       zuoWeiNumberXiuGai.setLocation(430,80);
       zheKouXiuGai.setSize(120,30);
       zheKouXiuGai.setLocation(430,135);
       qiFeiTimeXiuGai.setSize(120,30);
       qiFeiTimeXiuGai.setLocation(430,190);
       landTimeXiuGai.setSize(120,30);
       landTimeXiuGai.setLocation(430,245);
       xiuGaiButton.setSize(80,40);
       xiuGaiButton.setLocation(300,300);
       
       /*----------------------------�ͻ����Ͻ���ؼ�����----------------------*/
       throughCustomerTitle.setSize(200,50);
       throughCustomerTitle.setLocation(275,15);
       throughCustomerTitle.setFont(biaoTi);
       resultBianCustomer.setSize(700,250);
       resultBianCustomer.setLocation(16,100);
       buttonZhuJieMian_3.setSize(80,40);
       buttonZhuJieMian_3.setLocation(20,10);
    }
    public static void readToGraph(String FILEPATH,String filename,CityNode citynode) {
		String lineString="";
                String[] aircraftArray = new String[8];
		try {
			//�������System.out.println("�ļ���"+filename);
			File  file=new File(FILEPATH+filename);
			FileReader fr =new FileReader(file);
			BufferedReader br=new BufferedReader(fr);
			while((lineString=br.readLine())!=null){
				aircraftArray = lineString.split("-");
                             double luPrice=Double.parseDouble(aircraftArray[1]);
                             int    luZuoWei = Integer.parseInt(aircraftArray[2]);
                             HangBan hangban8 = new HangBan(aircraftArray[0],luPrice,luZuoWei,aircraftArray[3],aircraftArray[4],aircraftArray[5]);
                             citynode.addEdge(aircraftArray[6], aircraftArray[7], hangban8);
			}
			fr.close();
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    /**
     * ���ļ��еĳ��ж��뵽������ ������
     * @param FILEPATH
     * @param filename
     * @return 
     */
    public static String[] readToCity(String FILEPATH,String filename) {
		String lineString="";
              //String[] aircraftArray = new String[];
		try {
			//�������System.out.println("�ļ���"+filename);
			File  file=new File(FILEPATH+filename);
			FileReader fr =new FileReader(file);
			BufferedReader br=new BufferedReader(fr);
			while((lineString=br.readLine())!=null){
			String[] city = lineString.split("��");
                         return city;   
			}
			fr.close();
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
                return null;
	}
    public static void main(String[] args) {
       // new MainWindow("admin","admin","admin");
       new MainWindow("372926199708286315","xuan.0828","����");
      }

}

