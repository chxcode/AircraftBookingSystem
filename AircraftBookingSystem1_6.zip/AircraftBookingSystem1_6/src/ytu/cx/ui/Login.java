/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ytu.cx.ui;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import ytu.cx.util.MD5password;
import static ytu.cx.util.Tool.checkID;
/**
 *
 * @author changxuan
 */
public class Login extends JFrame{
    private String username=null;
    private String userName=null;
    private String password=null;
    private String fileNames=null;
    private MyPanel panel;
    private JLabel lb = new JLabel();     //��ʾ��֤��
    private JLabel lbRefresh = new JLabel("������");	
    private JLabel lan_YanCode = new JLabel("��֤��:"),fuHao = new JLabel("---*---*---*---*---*---*---*---*---*---*---*---*---*---*---*---*---*---");
    private JTextField jtn_YanCode = new JTextField();
    private JLabel lab_zhanghao = new JLabel("����֤��:");
    private JTextField jta_text = new JTextField();
    Font lab = new Font("����",1,20);
    private JLabel lat_password = new JLabel("��¼����:");
    Font lat  = new Font("����",1,20);
    private JPasswordField jtb_text = new JPasswordField();
    private JButton btn_register = new JButton("ע��");
    private JButton btn_land = new JButton("��½");
    Font btn = new Font("����",2,30);
    Font lbYanzheng=new Font("����",2,20);
    public static  int pd = 0;
    public static String ak1, ak2;
    private Container contentPane = this.getContentPane();
    public String getUserName(){
    	return userName;
    }
    public Login () {
        this.setSize(400,260);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setIconImage(new ImageIcon("./image/Plane.png").getImage());
        this.setTitle("��¼�ɻ���Ʊϵͳ");
        this.setResizable(false);
        
        lb.setText(makeYanZhengMa());
        lb.setForeground(new Color(0).green);
        lbRefresh.setFont(new Font("����",Font.HANGING_BASELINE,12));
        lbRefresh.setForeground(new Color(0).blue);
        /**
         * ע�ᰴť
         */
        lb.addMouseListener(new MouseAdapter(){
			//ˢ����֤��
			@Override
			public void mouseClicked(MouseEvent e) {				
				lb.setText(makeYanZhengMa());
			}			
		});
        lbRefresh.addMouseListener(new MouseAdapter(){
			//ˢ����֤��
			@Override
			public void mouseClicked(MouseEvent e) {				
				lb.setText(makeYanZhengMa());
			}			
		});
        btn_register.addActionListener(new ActionListener() {
            @SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
                        pd = 1;
                        new Register().setVisible(true);
                
                
            }
        });
        btn_land.addActionListener(new ActionListener() {
            @SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
                           
                        if(jtn_YanCode.getText().equals(lb.getText())){
					//��֤����ȷ
		        }else{
                            JOptionPane.showMessageDialog(null,"��֤���������������",null,JOptionPane.ERROR_MESSAGE, null);
                            lb.setText(makeYanZhengMa());
                            return;
			}	
                        
            	        if(pd==1||pd==0) {
                	File fileName=new File("./user/users.dat");
                	try{
                	FileReader inOne=new FileReader(fileName);
                	BufferedReader inTwo=new BufferedReader(inOne);
                	String s=null;
                	int judge=1;
                	while((s=inTwo.readLine())!=null)
                	{
                            String[] strsss=new String[4];
                            strsss=s.split("&&");
                            String strsssMd5 = "";
                            strsssMd5 = MD5password.MD5(jtb_text.getText());
                	     System.out.println(strsss[0]+strsss[1]+strsss[2]+strsss[3]);
                            if(jta_text.getText().equals(strsss[1])&&strsssMd5.equals(strsss[2])) {
                             if(strsss[3].equals("0")){
                                JOptionPane.showMessageDialog(null, "�˻��ѱ�ע��������ϵϵͳ����Ա��");
                                return;
                             }
                            JOptionPane.showMessageDialog(null, "��¼�ɹ���");
                            fileNames =jta_text.getText()+jtb_text.getText()+".txt";
                            userName=jta_text.getText();
                            password=jtb_text.getText();
                            username=strsss[0];
                            jta_text .setText("");
                            jtb_text .setText("");
                            judge=0;

                            break;
                            }
                	}  
                	inTwo.close();
                        inOne.close();
                	if(judge==1) {
                         JOptionPane.showMessageDialog(null,"��½ʧ�ܣ�����˺������Ƿ���ȷ����ע����¼",null,JOptionPane.ERROR_MESSAGE, null);
                         jta_text .setText("");
                         jtb_text .setText("");
                      }
                	 if(judge==0){
                                 //userName  ����֤��
                                 //username  �û�����   
                                 //password  ����
                                 if(username.equals("admin"))
                                   new MainWindowAdmin(userName,password,username).setVisible(true);                //new ������Ա����
                                 else
                                   new MainWindowUser(userName,password,username).setVisible(true);                      //new ���û�����
                		 dispose(); 
                               
                		 return; 
                	 }
                	}catch(IOException event){
                		JOptionPane.showMessageDialog(null,"ϵͳ����"+event,null,JOptionPane.ERROR_MESSAGE, null);
                	}
                }
            }
             
 
        });
         
        init();
         
        panel = new MyPanel();
        //�����е�������ӵ�panel�����
        panel.add(fuHao);
        panel.add(lan_YanCode);
        panel.add(lab_zhanghao);
        panel.add(lat_password);
        panel.add(jta_text);
        panel.add(jtb_text);
        panel.add(btn_register);
        panel.add(btn_land);
        panel.add(jtn_YanCode);
        panel.add(lb);
        panel.add(lbRefresh);
        panel.setLayout(null);
         
        getContentPane().add(panel);
    }
    private void init() {
        fuHao.setSize(380,5);
        fuHao.setLocation(10,110);
        lan_YanCode.setSize(200,50);
        lan_YanCode.setLocation(73,120);
        lan_YanCode.setFont(lat);
        lab_zhanghao.setSize(200,50);
        lab_zhanghao. setLocation(50,10);
        lab_zhanghao.setFont(lab);
        lat_password.setSize(200,50);
        lat_password.setLocation(50,65);
        lat_password.setFont(lat);
        jta_text.setSize(190,30);
        jta_text.setLocation(160,20);
        jtb_text.setSize(190,30);
        jtb_text.setLocation(160,75);
        jtn_YanCode.setSize(80,30);
        jtn_YanCode.setLocation(160,130);
        lb.setBounds(255, 130, 90, 30);  
        lb.setFont(lbYanzheng);
        lbRefresh.setBounds(350, 130, 50, 30);
        
        btn_register.setSize(120, 40);
        btn_register.setLocation(60, 180);
        btn_land.setSize(120, 40);
        btn_land.setLocation(230, 180);
        btn_register.setFont(btn);
        btn_land.setFont(btn);
        
    }
    //���������֤��
	public String makeYanZhengMa(){
		String[] str = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z",
				"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z",
				"0","1","2","3","4","5","6","7","8","9"};
		Random random = new Random();
		int i = random.nextInt(62);
		int j = random.nextInt(62);
		int k = random.nextInt(62);
		int z = random.nextInt(62);
		int x = random.nextInt(62);
		int y = random.nextInt(62);
		return str[i]+str[j]+str[k]+str[z]+str[x]+str[y];
	}	
    public static void main(String[] args)
    throws ClassNotFoundException,
        InstantiationException, IllegalAccessException,
        UnsupportedLookAndFeelException {
        UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
        new Login().setVisible(true);
    }
    
}
