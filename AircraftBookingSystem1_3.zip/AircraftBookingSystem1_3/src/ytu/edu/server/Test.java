/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ytu.edu.server;

import java.io.File;

/**
 *
 * @author changxuan
 */
public class Test {
    public static void main(String[] args){
        String strload=".//flight_information";
        System.out.println("start");
        testDir(strload);
        System.out.println("OK!");
    }
    
    /**
     * �ж��ļ������Ƿ����txt�ļ�
     * @param path
     * @return 
     */
    public static void testDir(String path)
  {
    File f = new File(path);
     if (f.exists() && f.isDirectory())
     {
         System.out.println(f.listFiles().length);
       if (f.listFiles().length > 0)
       {
            System.out.println("�ļ����д����ļ�");
           //return true;
       }
       else{
            System.out.println("�ļ����в������ļ�");
            //return false;
       }
          
     }
     //return false;
  }
}
