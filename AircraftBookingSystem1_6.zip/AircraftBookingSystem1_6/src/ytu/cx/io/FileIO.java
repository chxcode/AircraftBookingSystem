/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ytu.cx.io;

/**
 *
 * @author Administrator
 */
public abstract class FileIO {
	//public abstract void checkFile(String FILEPATH,String filename);
	public abstract void write(String FILRPATH,String data,boolean mode,String filename);
	public abstract  String read(String FILEPATH,String filename);
	
}
