/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ytu.cx.store;

import ytu.cx.util.Tool;

/**
 *
 * @author changxuan
 */
public class HangBan {
    public String HangBanHao;
    public double price;
    public int    seatNumber;
    public String discount;
    public String startTime;
    public String lendTime;
    public long    timeLength=0;
    public HangBan(String HangBanHao,double price,int seatNumber,String discount,String startTime,String lendTime){
        this.HangBanHao = HangBanHao;
        this.price = price;
        this.seatNumber = seatNumber;
        this.discount = discount; 
        this.startTime = startTime;
        this.lendTime  = lendTime;
        this.timeLength=Tool.getPlayTime(startTime, lendTime);
        //System.out.println(this.timeLength);
        
    }
    
}
